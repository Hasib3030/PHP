<?php

$username=$_POST['username'];
$password=$_POST['password'];
$dob=$_POST['dob'];
$add=$_POST['address'];
$dept=$_POST['dept'];
$gender=$_POST['gender'];


echo $username."  ". $password."   ". $dob."    ". $add."    ". $dept."   ". $gender;

?>